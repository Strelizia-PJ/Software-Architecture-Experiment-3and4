package com;
public interface TaxCaculateInterface {
    public float Caculate(float income);
}
